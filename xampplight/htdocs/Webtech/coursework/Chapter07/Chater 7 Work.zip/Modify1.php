<!DOCTYPE html>
<!--Author:
	Date:
	File:	Modify1.php
	Purpose:Chapter 7 Exercise

		Modify1.html provides a form asking the user to enter their age.
		Modify1.php calculates and displays the number of years until
		retirement, even if the user enters 65 or above!
		Change Modify1.php so that the progam either calculates and displays
		the years until retirement, or else calculates and displays the number of
		years the person has been retired. To do this, use an IF..ELSE structure
		to test the age. Assume that someone less than 65
		is not retired, someone 65 or older is retired
-->
<!-- COMPLETED -->
<html>
<head>
	<title>Modify1</title>
	<link rel ="stylesheet" type="text/css" href="sample.css" >
</head>
<body>

	<h1>Modify1</h1>

	<?php
		$age = $_POST['age'];
		$yearsToRetire = 65 - $age;

		if ($age < 65)
		{
			print("<p>Your age is $age. You have $yearsToRetire years until retirement.</p>");
		}

		else if ($age >= 65)
		{
			print("<p>Your age is $age, so you are retired!</p>");
		}
	?>

</body>
</html>
