<!DOCTYPE html>
<!--Author: Ethan Green
	Date:   March 13
	File:	softwareOrder.php
	Purpose:Chapter 7 Assignment 2

-->
<!-- COMPLETED -->
<html>
<head>
	<title>SaveTheWorld Software</title>
	<link rel ="stylesheet" type="text/css" href="sample.css" />
</head>
<body>

	<h1>YOUR ORDER:</h1>

	<?php
		$os = $_POST['os'];
		$numCopies = $_POST['numCopies'];

		$subTotal = $numCopies * 35.00;
		$salesTax = $subTotal * 0.07;

		if ($numCopies < 5)
			$shippingAndHandling = 3.50;
		
		else if ($numCopies >= 5)
			$shippingAndHandling = .75 * $numCopies;

		$totalCost = $subTotal + $salesTax + $shippingAndHandling;

		print("<table border = \"2\"><tr><td>Operating System</td><td>$os</td></tr>");
		print("<tr><td>Number of copies</td><td>$numCopies</td><td>");
		print("<tr><td>Sub-total</td><td align=\"right\">$".number_format($subTotal, 2)."</td></tr>");
		print("<tr><td>Sales tax</td><td align=\"right\">$".number_format($salesTax, 2)."</td></tr>");
		print("<tr><td>Shipping and handling</td><td align=\"right\">$".number_format($shippingAndHandling, 2)."</td></tr>");
		print("<tr><td>TOTAL:</td><td align=\"right\">$".number_format($totalCost, 2)."</td></tr></table>");
	?>

</body>
</html>
